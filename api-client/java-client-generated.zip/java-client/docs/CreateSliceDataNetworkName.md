
# CreateSliceDataNetworkName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceId** | **String** |  | 
**operationId** | **String** |  | 



