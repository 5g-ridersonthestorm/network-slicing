
# ViewSliceMetric

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **String** |  | 
**time** | **Integer** |  | 



